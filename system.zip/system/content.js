(() => {
  const MIN_SELECTION_LENGTH = 10;

  let questionsCache = null;

  let overlay = null;
  let currentAbortController = null;

  // ─── Force-enable Text Selection ─────────────────────────────────────────────

  // Override CSS user-select: none on all elements
  const selectionStyle = document.createElement('style');
  selectionStyle.textContent = `
    *, *::before, *::after {
      -webkit-user-select: text !important;
      user-select: text !important;
    }
  `;
  document.documentElement.appendChild(selectionStyle);

  // Block JS handlers that prevent selection or copying
  document.addEventListener('selectstart', (e) => e.stopImmediatePropagation(), true);
  document.addEventListener('copy',        (e) => e.stopImmediatePropagation(), true);

  // ─── Overlay Factory ─────────────────────────────────────────────────────────

  function createOverlay() {
    const el = document.createElement('div');
    el.id = 'tsa-overlay';
    el.setAttribute('role', 'status');
    el.setAttribute('aria-live', 'polite');
    document.body.appendChild(el);
    return el;
  }

  function getOverlay() {
    if (!overlay || !document.body.contains(overlay)) {
      overlay = createOverlay();
    }
    return overlay;
  }

  // ─── Positioning ─────────────────────────────────────────────────────────────

  function positionOverlay(el, x, y) {
    // Temporarily show off-screen to measure dimensions
    el.style.visibility = 'hidden';
    el.style.display = 'block';

    const MARGIN = 12;
    const vw = window.innerWidth;
    const vh = window.innerHeight;
    const rect = el.getBoundingClientRect();

    let left = x + MARGIN;
    let top = y + MARGIN;

    // Flip horizontal if clipped
    if (left + rect.width > vw - MARGIN) {
      left = x - rect.width - MARGIN;
    }
    // Flip vertical if clipped
    if (top + rect.height > vh - MARGIN) {
      top = y - rect.height - MARGIN;
    }

    // Clamp to viewport
    left = Math.max(MARGIN, left);
    top  = Math.max(MARGIN, top);

    el.style.left = `${left + window.scrollX}px`;
    el.style.top  = `${top  + window.scrollY}px`;
    el.style.visibility = 'visible';
  }

  // ─── State Helpers ───────────────────────────────────────────────────────────

  function showLoading(x, y) {
    const el = getOverlay();
    el.className = 'tsa-loading';
    el.innerHTML = `
      <div class="tsa-header">
        <span class="tsa-icon">🔍</span>
        <span class="tsa-title">Test Solver</span>
        <button class="tsa-close" aria-label="Close">✕</button>
      </div>
      <div class="tsa-body">
        <div class="tsa-spinner"></div>
        <span>Searching…</span>
      </div>`;
    el.querySelector('.tsa-close').addEventListener('click', removeOverlay);
    positionOverlay(el, x, y);
  }

  function showAnswer(answer) {
    const el = getOverlay();
    el.className = 'tsa-result';
    el.innerHTML = `
      <div class="tsa-header">
        <span class="tsa-icon">✅</span>
        <span class="tsa-title">Answer Found</span>
        <button class="tsa-close" aria-label="Close">✕</button>
      </div>
      <div class="tsa-body">
        <p class="tsa-answer">${escapeHtml(answer)}</p>
      </div>`;
    el.querySelector('.tsa-close').addEventListener('click', removeOverlay);
  }

  function showError(message = 'No answer found.') {
    const el = getOverlay();
    el.className = 'tsa-error';
    el.innerHTML = `
      <div class="tsa-header">
        <span class="tsa-icon">⚠️</span>
        <span class="tsa-title">Test Solver</span>
        <button class="tsa-close" aria-label="Close">✕</button>
      </div>
      <div class="tsa-body">
        <p class="tsa-error-msg">${escapeHtml(message)}</p>
      </div>`;
    el.querySelector('.tsa-close').addEventListener('click', removeOverlay);
  }

  function removeOverlay() {
    if (currentAbortController) {
      currentAbortController.abort();
      currentAbortController = null;
    }
    if (overlay && document.body.contains(overlay)) {
      const el = overlay;
      overlay = null;
      el.classList.add('tsa-fade-out');
      el.addEventListener('animationend', () => el.remove(), { once: true });
    } else {
      overlay = null;
    }
  }

  // ─── JSON Lookup ─────────────────────────────────────────────────────────────

  async function loadQuestions() {
    if (questionsCache) return questionsCache;
    const url = chrome.runtime.getURL('data.json');
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to load data.json');
    questionsCache = await response.json();
    return questionsCache;
  }

  async function fetchAnswer(query) {
    const questions = await loadQuestions();
    const q = query.toLowerCase();

    // Try to find a question that contains the selected text or vice versa
    const match = questions.find(item =>
      item.question.toLowerCase().includes(q) ||
      q.includes(item.question.toLowerCase())
    );

    if (!match) throw new Error('No answer found');
    return match.answer;
  }

  // ─── Main Handler ─────────────────────────────────────────────────────────────

  document.addEventListener('mouseup', async (e) => {
    // Ignore clicks inside our own overlay
    if (overlay && overlay.contains(e.target)) return;

    const selection = window.getSelection();
    const selectedText = selection?.toString().trim() ?? '';

    if (selectedText.length <= MIN_SELECTION_LENGTH) {
      removeOverlay();
      return;
    }

    // Copy selected text to clipboard before showing the answer
    try { await navigator.clipboard.writeText(selectedText); } catch (_) {}

    showLoading(e.clientX, e.clientY);

    try {
      const answer = await fetchAnswer(selectedText);
      showAnswer(answer);
    } catch (err) {
      if (err.name === 'AbortError') return; // User dismissed — do nothing
      showError( 'No answer found.');
    }
  });

  // Dismiss on any mousedown outside the overlay
  document.addEventListener('mousedown', (e) => {
    if (overlay && !overlay.contains(e.target)) {
      removeOverlay();
    }
  });

  // ─── Utility ─────────────────────────────────────────────────────────────────

  function escapeHtml(str) {
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
})();
