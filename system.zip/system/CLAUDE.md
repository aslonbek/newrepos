# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Chrome Extension (Manifest V3) called **Test Solver Assistant** — a content script that listens for text selections on any webpage and searches for matching answers in a local Q&A database (`data.json`). The Q&A data is in Uzbek (Cyrillic script) covering educational topics.

## Loading & Testing

No build process — load directly into Chrome:
1. Go to `chrome://extensions/`
2. Enable **Developer mode**
3. Click **Load unpacked** → select this directory

To reload after code changes: click the refresh icon on the extension card in `chrome://extensions/`.

Manual testing only (no test framework). Open any webpage, highlight 10+ characters of text, and verify the overlay appears.

## Architecture

All logic lives in a single IIFE in [content.js](content.js). The extension flow:

1. `mouseup` event fires → checks selection length ≥ 10 chars
2. `loadQuestions()` fetches and caches `data.json` (only loaded once per page)
3. `fetchAnswer(query)` does a case-insensitive substring match against question fields
4. Result displayed via overlay DOM element (`#tsa-overlay`) styled by [style.css](style.css)

**Key implementation details:**
- `data.json` is listed in `manifest.json` under `web_accessible_resources` so the content script can `fetch()` it via `chrome.runtime.getURL()`
- Overlay positioning uses viewport-edge detection to flip left/right and top/bottom
- `AbortController` cancels in-flight fetches when a new selection starts
- `escapeHtml()` sanitizes all user-derived content before inserting into the DOM

## Files

| File | Purpose |
|------|---------|
| `manifest.json` | Extension metadata, permissions (`activeTab`, `<all_urls>`), script/CSS registration |
| `content.js` | All extension logic (selection listener, fetch, overlay rendering) |
| `style.css` | Overlay UI styles, animations |
| `data.json` | ~2,000 Uzbek Q&A pairs `[{question, answer}]` |
| `icons/` | Extension icons (16, 48, 128 px) |
